import { Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import DetalleProducto from "./pages/DetalleProducto";
import Formulario from "./pages/Formulario";
import Inicio from "./pages/Inicio";
import NoEncontrado from "./pages/NoEncontrado";
import Tienda from "./pages/Tienda";

function App() {
  return (
    <div>
      <Navbar />
      <main className="container pb-5">
        <Routes>
          {/*rutas sin parametros*/}
          <Route path="/" element={<Inicio />} />
          <Route path="/Tienda" element={<Tienda />} />
          <Route path="/formulario" element={<Formulario />} />

          {/*rutas con parametros*/}
          <Route path="/producto/:id" element={<DetalleProducto />} />

          {/*ruta comodin*/}
          <Route path="*" element={<NoEncontrado />} />
        </Routes>
      </main>
    </div>
  );
}

export default App